// Init Process (PID 1) for AutomationOS
// Spawns and manages system services using SYS_SPAWN (no fork required)

typedef unsigned long size_t;

// Syscall numbers matching kernel/include/syscall.h
#define SYS_EXIT    0
#define SYS_READ    2
#define SYS_WRITE   3
#define SYS_GETPID  8
#define SYS_SLEEP   9
#define SYS_SPAWN   16
#define SYS_WAITPID 6
#define SYS_YIELD   15

static inline long syscall(long n, long a1, long a2, long a3) {
    long ret;
    asm volatile (
        "syscall"
        : "=a"(ret)
        : "a"(n), "D"(a1), "S"(a2), "d"(a3)
        : "rcx", "r11", "memory"
    );
    return ret;
}

static size_t strlen(const char* s) {
    size_t len = 0;
    while (s[len]) len++;
    return len;
}

static void print(const char* msg) {
    syscall(SYS_WRITE, 1, (long)msg, strlen(msg));
}

static void print_num(long n) {
    char buf[20];
    int i = 0;
    if (n < 0) { print("-"); n = -n; }
    do { buf[i++] = '0' + (n % 10); n /= 10; } while (n > 0);
    while (i > 0) { char c = buf[--i]; syscall(SYS_WRITE, 1, (long)&c, 1); }
}

static int spawn(const char* path) {
    int pid = (int)syscall(SYS_SPAWN, (long)path, 0, 0);
    if (pid < 0) {
        print("[INIT] Spawn failed for ");
        print(path);
        print("\n");
    }
    return pid;
}

static void yield(void) {
    syscall(SYS_YIELD, 0, 0, 0);
}

static void sleep(int ms) {
    syscall(SYS_SLEEP, ms, 0, 0);
}

void _start(void) {
    print("[INIT] ==========================================\n");
    print("[INIT]   AutomationOS Init (PID 1)\n");
    print("[INIT]   Starting userspace services...\n");
    print("[INIT] ==========================================\n");

    int my_pid = (int)syscall(SYS_GETPID, 0, 0, 0);
    if (my_pid != 1) {
        print("[INIT] ERROR: Not PID 1!\n");
        syscall(SYS_EXIT, 1, 0, 0);
    }

    print("[INIT] Spawning compositor...\n");
    int compositor_pid = spawn("sbin/compositor");
    if (compositor_pid > 0) {
        print("[INIT] Compositor started (PID ");
        print_num(compositor_pid);
        print(")\n");
    } else {
        print("[INIT] ERROR: Failed to spawn compositor!\n");
    }
    // M3: spawn a test client that creates a window over the SHM protocol.
    // (No settle delay: both processes are queued and the SysV inbox queue is
    // created with IPC_CREAT by whichever side calls msgget first.)
    print("[INIT] Spawning terminal...\n");
    int term_pid = spawn("sbin/terminal");
    if (term_pid > 0) {
        print("[INIT] terminal started (PID ");
        print_num(term_pid);
        print(")\n");
    } else {
        print("[INIT] ERROR: Failed to spawn terminal!\n");
    }

    print("[INIT] Spawning file manager...\n");
    int fm_pid = spawn("sbin/filemanager");
    if (fm_pid > 0) {
        print("[INIT] filemanager started (PID ");
        print_num(fm_pid);
        print(")\n");
    } else {
        print("[INIT] ERROR: Failed to spawn filemanager!\n");
    }

    // NOTE: the right-side dock IS the launcher now, so we no longer auto-open
    // the Applications grid window (it duplicated the dock + covered the desktop).
    print("[INIT] Spawning date/clock...\n");
    spawn("sbin/dateapp");

    print("[INIT] All services started!\n");

    while (1) {
        int status;
        int pid = (int)syscall(SYS_WAITPID, -1, (long)&status, 0);
        if (pid > 0) {
            print("[INIT] Process ");
            print_num(pid);
            print(" exited with status ");
            print_num(status);
            print("\n");

            if (pid == compositor_pid) {
                print("[INIT] Restarting compositor...\n");
                compositor_pid = spawn("sbin/compositor");
            }
        } else {
            yield();
        }
    }
}
