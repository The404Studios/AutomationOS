# AutomationOS Boot Readiness Report

**Date:** 2026-05-26
**Assessed by:** Final Boot Readiness Agent (63 agents completed prior work)
**Verdict:** NOT READY TO BOOT -- critical compile-time and boot-time bugs must be fixed first

---

## Executive Summary

AutomationOS is an ambitious custom x86_64 UEFI operating system with a kernel, bootloader, userspace libc, init system, shell, compositor, and desktop environment. After thorough analysis of every build artifact, linker script, header dependency, and runtime flow, the system is **not yet bootable** in its current state.

The good news: the architecture is sound, the build system is well-structured, and all major subsystems exist. The bad news: there are 8 critical blockers that will prevent compilation or cause immediate crashes at boot, plus several medium-severity issues.

**Realistic probability of a clean first boot:** 0% as-is. After fixing the 8 critical blockers documented below: approximately 40-50% chance of reaching the kernel banner; 15-25% chance of reaching the idle loop or loading init.

---

## System Inventory

### Source File Count

| Directory     | Source Files | Description                                        |
|---------------|-------------:|----------------------------------------------------|
| boot/         |           14 | UEFI bootloader (assembly, C, linker script)       |
| kernel/       |          193 | Kernel core, arch, drivers, fs, security, crypto   |
| userspace/    |          122 | libc, init, shell, compositor, desktop, apps       |
| tests/        |           59 | Unit, integration, fuzz, stress, race condition     |
| scripts/      |           39 | Build, CI/CD, toolchain, analysis scripts          |
| benchmarks/   |           10 | Micro and macro benchmarks                         |
| tools/        |            5 | Auxiliary development tools                        |
| **Total**     |      **442** | Source files (C, H, ASM, LD, SH, PY)              |

### Lines of Code (estimated)

| Component          | LOC (approx) |
|--------------------|-------------:|
| boot/              |        2,900 |
| kernel/            |       35,000 |
| userspace/         |       18,000 |
| tests/             |        8,000 |
| scripts/           |        5,000 |
| benchmarks/        |        2,000 |
| Documentation (MD) |       80,000 |
| **Total source**   |   **~71,000** |
| **Total with docs**|  **~151,000** |

The 200,000 LOC figure from project claims includes documentation. Actual compilable source code is approximately 71,000 lines.

### Major Components

**Bootloader (boot/)**
- `boot.asm` -- UEFI entry point (NASM, 64-bit)
- `loader.c` -- UEFI boot services: memory map, GOP graphics, ELF loading, ExitBootServices
- `boot.h` -- UEFI type definitions, ELF structures, boot_info_t
- `boot.ld` -- Bootloader linker script (base 0x100000)

**Kernel (kernel/)**
- `kernel.c` -- Main kernel entry, subsystem initialization chain
- `linker.ld` -- Kernel linker script (base 0xFFFFFFFF80000000, higher-half)
- `arch/x86_64/` -- GDT, IDT, interrupt handlers, syscall entry, paging, SMP, usermode
- `core/mem/` -- PMM (buddy allocator with per-CPU caches), VMM, heap
- `core/sched/` -- Process management, scheduler, context switch
- `core/syscall/` -- Syscall dispatcher, handlers
- `drivers/` -- Serial, framebuffer, PS/2, PIT, NVMe, AHCI, USB, HDA, wireless
- `fs/` -- VFS layer, ramfs, AutoFS, ELF loader, initrd (TAR format)
- `security/` -- MAC, seccomp, capabilities, namespaces
- `init/` -- Initrd parser, ELF loader, enhanced main

**Userspace (userspace/)**
- `libc/` -- Minimal C library (syscall wrappers, stdio, string)
- `init/init.c` -- PID 1 init process (forks shell, reaps children)
- `shell/` -- Command shell with parser
- `compositor/` -- Window compositor with animations, blur, shadows
- `shell/desktop/` -- Desktop shell (panel, dock, notifications)
- `apps/` -- File explorer, settings, task manager, terminal
- `wm/` -- Window manager

### Build System

- Top-level `Makefile` orchestrates: bootloader -> kernel -> userspace -> ISO
- `configure` script generates `config.mk` and `include/config.h`
- `scripts/build-iso.py` creates UEFI bootable ISO via xorriso
- `scripts/run-qemu.sh` launches QEMU
- `Dockerfile.build` provides reproducible build environment
- Toolchain: `x86_64-elf-gcc`, `x86_64-elf-ld`, `nasm`

---

## CRITICAL BLOCKERS (Must Fix Before Compiling)

### BLOCKER 1: run-qemu.sh Missing UEFI Firmware

**File:** `scripts/run-qemu.sh`

The bootloader is a UEFI application (`BOOTX64.EFI`), but `run-qemu.sh` uses `-cdrom` without `-bios /usr/share/ovmf/OVMF.fd`. Without OVMF firmware, QEMU will try legacy BIOS boot and the EFI binary will not execute.

The separate `boot/test-qemu.sh` correctly uses OVMF and creates a FAT32 ESP image, but the top-level `make qemu` target calls `scripts/run-qemu.sh` which does not.

**Fix:** Add OVMF firmware flag to `scripts/run-qemu.sh` and switch from `-cdrom` to a proper UEFI boot drive.

### BLOCKER 2: kprintf Does Not Support Format Specifiers Used by kernel.c

**File:** `kernel/lib/printf.c`

`kprintf` only supports: `%s`, `%d`, `%u`, `%x`, `%p`, `%%`.

`kernel/kernel.c` uses:
- `%llu` (line 145) -- unsigned 64-bit: NOT SUPPORTED
- `%lu` (line 175, 176) -- unsigned long: NOT SUPPORTED
- `%016lx` (line 198, 224, 228) -- padded 64-bit hex: NOT SUPPORTED
- `%.2f` (line 146) -- floating-point: NOT SUPPORTED

These will either print garbage, skip the argument, or misalign the va_list (corrupting all subsequent arguments), likely causing a crash.

**Fix:** Extend kprintf to handle `%l`, `%ll`, width/padding specifiers. Remove `%.2f` calls (use integer division for milliseconds instead).

### BLOCKER 3: Floating-Point in Kernel Code

**File:** `kernel/include/perf.h` (lines 52-58)

`cycles_to_us()` and `cycles_to_ms()` use `double` type. The kernel is compiled with `-mno-red-zone` and `-mcmodel=kernel` but NOT `-mno-sse -mno-mmx`. In a freestanding kernel, floating-point operations are dangerous because:
1. The FPU/SSE state is not initialized at boot
2. The compiler may emit SSE instructions that fault if SSE is not enabled in CR0/CR4
3. FPU state is not saved/restored across interrupts

Even if SSE happens to work, using `double` in kernel printf is wrong since kprintf does not support `%f`.

**Fix:** Replace floating-point conversions with integer arithmetic (e.g., `cycles * 1000 / cpu_freq_mhz` for microseconds).

### BLOCKER 4: Duplicate Function Definitions (ODR Violation)

**Files:** `kernel/include/spinlock.h` and `kernel/include/x86_64.h`

Both files define `save_flags_cli()` and `restore_flags()` as `static inline` functions. Any C file that includes both headers (directly or transitively) will get duplicate definitions. The linker may or may not error, but the compiler will warn.

More critically, `spinlock.h` includes `types.h` but NOT `x86_64.h`, and defines its own copies of `save_flags_cli`/`restore_flags`. This means the two versions could diverge.

**Fix:** Remove the duplicates from one of the two headers; have `spinlock.h` include `x86_64.h` for the arch primitives.

### BLOCKER 5: 18 Kernel Source Files Include <stdio.h> / <stdlib.h>

**Files:** All files in `kernel/pe/` and `kernel/fs/autofs/`

These standard library headers do not exist in a freestanding cross-compilation environment. The compilation will fail immediately for every file in:
- `kernel/pe/` (7 files) -- PE loader, Win32 API stubs, DLL loader, registry, handles
- `kernel/fs/autofs/` (11 files) -- AutoFS filesystem implementation

**Fix:** Replace `#include <stdio.h>` with `#include "../../include/kernel.h"` (for kprintf) and `#include <stdlib.h>` with `#include "../../include/mem.h"` (for kmalloc/kfree). Replace any references to `printf`, `malloc`, `free`, `calloc`, `realloc`, `memcpy` with their kernel equivalents.

### BLOCKER 6: Bootloader Output Format is ELF, Not PE/COFF

**Files:** `boot/Makefile`, `boot/boot.ld`

The bootloader compiles to `BOOTX64.EFI` but uses:
- NASM with `-f elf64` (ELF object format)
- `x86_64-elf-ld` with a standard ELF linker script

UEFI firmware expects PE/COFF (Portable Executable) format, not ELF. Naming the output `BOOTX64.EFI` does not make it a valid PE file. UEFI will reject it.

**Fix options:**
1. Use `x86_64-elf-objcopy -O pei-x86-64` to convert ELF to PE
2. Use a UEFI development kit (gnu-efi or EDK2) which handles the PE format correctly
3. Add a PE header to the assembly and use a PE-aware linker

This is the single most critical blocker. Without a valid PE binary, the UEFI firmware cannot even load the bootloader.

### BLOCKER 7: Kernel Linker Script Assumes Higher-Half but Bootloader Maps at Physical

**Files:** `kernel/linker.ld`, `boot/loader.c`

The kernel's linker script places code at virtual address `0xFFFFFFFF80000000` (higher-half). But the bootloader:
1. Loads the kernel ELF and copies segments to their `p_paddr` (physical address)
2. Jumps to `elf->e_entry` (which will be a virtual address like 0xFFFFFFFF80000000+offset)
3. Does NOT set up page tables mapping the higher-half virtual addresses

After `ExitBootServices`, the CPU is in long mode (set up by UEFI) with identity-mapped memory. When the bootloader jumps to the kernel entry point at a higher-half address, there is no mapping for that address, causing an immediate page fault (and since the IDT is not set up, a triple fault and reboot).

**Fix:** Either:
1. The bootloader must set up page tables mapping the higher-half before jumping to the kernel, OR
2. The kernel must include a trampoline in a lower section (identity-mapped) that sets up paging and then jumps to the higher-half code, OR
3. Change the kernel linker script to load at a physical address temporarily

### BLOCKER 8: No Initrd Creation Tool or Mechanism

**Files:** `kernel/kernel.c` (lines 156-241)

The kernel expects `boot_info->initrd_addr` and `boot_info->initrd_size` to contain a TAR-format initrd. But:
1. The bootloader does NOT load an initrd (there is no initrd loading code in `loader.c`)
2. There is no script to create an initrd TAR archive from the userspace binaries
3. The ISO builder does not package an initrd
4. `boot_info->initrd_addr` and `boot_info->initrd_size` will be 0

Without an initrd, the kernel will print "WARNING: No initrd found" and enter the idle loop. The system will never start init or any userspace process.

**Fix:**
1. Create a script that builds a TAR archive of userspace binaries (init, shell, etc.)
2. Add initrd loading to the bootloader (load the TAR file from the ESP filesystem)
3. Pass the initrd address/size via boot_info

---

## MEDIUM SEVERITY ISSUES

### ISSUE M1: Bootloader Frees Kernel Pages Before Jumping

**File:** `boot/loader.c` (line 424)

After loading ELF segments to their target addresses, the bootloader calls `BS->FreePages(kernel_addr, pages)` to free the temporary load buffer. This is correct. However, the `AllocatePages` call at line 397 uses type `1` (AllocateAnyPages) but passes `seg_addr = phdr[i].p_paddr` -- if the firmware allocates at a different address, the memcpy target is wrong.

### ISSUE M2: No GDT User Segments in GDT Table

**File:** `kernel/arch/x86_64/gdt.c`

The GDT is declared as `static gdt_entry_t gdt[5]` (5 entries: null, kernel code, kernel data, user code(?), user data(?)). But usermode.asm uses selectors 0x1B (entry 3, RPL=3) and 0x23 (entry 4, RPL=3). We need to verify that entries 3 and 4 are properly configured as user-mode segments, not just the standard kernel code/data segments.

### ISSUE M3: Syscall Stack Switch

**File:** `kernel/arch/x86_64/syscall.asm`

The syscall entry point does not switch to a kernel stack. When `SYSCALL` executes, RSP still points to the user stack. The assembly pushes registers onto the user stack, which is a security vulnerability (user can control the stack pointer). The TSS.RSP0 mechanism only applies to hardware interrupts, not `SYSCALL`.

### ISSUE M4: Missing UINT64_MAX Definition Guard

**File:** `kernel/include/types.h`

`UINT64_MAX` is defined at the bottom of types.h. Some files include `<stdint.h>` which also defines it. If both are included, there will be a redefinition warning/error. Needs an `#ifndef` guard.

### ISSUE M5: ISO Build Puts Kernel in Wrong Location

**File:** `scripts/build-iso.py`

The ISO builder copies the kernel to `iso/boot/kernel.elf`, but the bootloader looks for it at `\EFI\BOOT\KERNEL.ELF` (line 307 of loader.c), falling back to `\KERNEL.ELF` (line 311). The ISO path `boot/kernel.elf` would appear as `\boot\kernel.elf` on the filesystem, which matches neither search path.

---

## Step-by-Step Boot Guide (After Fixing All Blockers)

### Prerequisites

```bash
# Ubuntu 22.04 / WSL2
sudo apt update
sudo apt install -y build-essential nasm python3 git qemu-system-x86 \
    xorriso mtools ovmf dosfstools

# Install cross-compiler
# Option A: From package (if available)
sudo apt install gcc-x86-64-linux-gnu

# Option B: Build from source (recommended for bare-metal target)
./scripts/setup-toolchain.sh --build

# Verify tools
x86_64-elf-gcc --version
x86_64-elf-ld --version
nasm --version
qemu-system-x86_64 --version
```

### Build Steps

```bash
# 1. Configure
cd ~/Desktop/Kernel
chmod +x configure
./configure --enable-debug

# 2. Build bootloader
make bootloader
# Expected output: build/BOOTX64.EFI

# 3. Build kernel
make kernel
# Expected output: build/kernel.elf

# 4. Build userspace
make userspace
# Expected output: build/userspace/libc/libc.a, build/userspace/init/init, etc.

# 5. Create initrd (MUST BE IMPLEMENTED - does not exist yet)
# tar -cf build/initrd.tar -C build/userspace init/init shell/shell
# This needs a proper script that creates a ustar-format TAR

# 6. Create ISO
make iso
# Expected output: build/AutomationOS.iso

# 7. Boot in QEMU
# With OVMF firmware (CRITICAL - must use UEFI mode):
qemu-system-x86_64 \
    -bios /usr/share/ovmf/OVMF.fd \
    -drive file=build/AutomationOS.iso,format=raw,if=ide \
    -m 4G \
    -smp 4 \
    -serial stdio \
    -vga std \
    -no-reboot \
    -no-shutdown
```

### What To Expect On Screen (If Everything Works)

1. OVMF firmware splash (1-2 seconds)
2. UEFI Shell or bootloader loads
3. Serial output shows:
```
AutomationOS UEFI Bootloader
=============================
[1/4] Querying memory map...
  Memory map acquired:  usable regions
[2/4] Setting up graphics...
  Graphics mode:
[3/4] Loading kernel...
  Kernel size:  bytes
  Kernel loaded
[4/4] Parsing ELF...
  Entry point: 0x

Exiting boot services...
```
4. After ExitBootServices, kernel output on serial:
```
=====================================
   AutomationOS v0.1.0
=====================================

[PERF] gdt_init: ... cycles
[PERF] pmm_init: ... cycles
[PERF] vmm_init: ... cycles
[PERF] heap_init: ... cycles
[PERF] idt_init: ... cycles
...
[KERNEL] All subsystems initialized
[KERNEL] Free memory: ... MB
[KERNEL] Starting init process...
```
5. If initrd is present and loaded correctly, init starts
6. If no initrd: "WARNING: No initrd found" then idle loop

---

## Boot Checklist

- [ ] Cross-compiler toolchain installed (`x86_64-elf-gcc`, `x86_64-elf-ld`, `nasm`)
- [ ] QEMU installed (`qemu-system-x86_64`)
- [ ] OVMF firmware installed (`/usr/share/ovmf/OVMF.fd`)
- [ ] xorriso installed (for ISO creation)
- [ ] **BLOCKER 1 FIXED:** run-qemu.sh uses OVMF firmware
- [ ] **BLOCKER 2 FIXED:** kprintf supports %llu, %lu, %lx with width/padding
- [ ] **BLOCKER 3 FIXED:** Floating-point removed from kernel code
- [ ] **BLOCKER 4 FIXED:** Duplicate function definitions resolved
- [ ] **BLOCKER 5 FIXED:** <stdio.h>/<stdlib.h> replaced in 18 kernel files
- [ ] **BLOCKER 6 FIXED:** Bootloader outputs valid PE/COFF (not ELF)
- [ ] **BLOCKER 7 FIXED:** Higher-half mapping established before kernel jump
- [ ] **BLOCKER 8 FIXED:** Initrd creation tool exists and bootloader loads it
- [ ] **ISSUE M5 FIXED:** ISO places kernel at correct path for bootloader
- [ ] `./configure` runs successfully
- [ ] `make bootloader` compiles without errors
- [ ] `make kernel` compiles without errors
- [ ] `make userspace` compiles without errors
- [ ] Initrd TAR archive created with init and shell binaries
- [ ] `make iso` generates build/AutomationOS.iso
- [ ] QEMU boots to OVMF firmware
- [ ] Bootloader loads and displays banner
- [ ] Kernel loads and displays version banner
- [ ] Memory subsystem initializes (PMM, VMM, heap)
- [ ] Interrupts initialize (GDT, IDT, PIT)
- [ ] Initrd mounts successfully
- [ ] Init process starts in user mode
- [ ] Shell spawns

---

## Risk Assessment

### What Will Fail on First Compile

1. **Guaranteed failures:** All 18 files in `kernel/pe/` and `kernel/fs/autofs/` that include `<stdio.h>`/`<stdlib.h>` will fail. Since the kernel Makefile uses `find . -name "*.c"` to gather ALL C files, these broken files are included in the build.

2. **Likely failures:** The duplicate `save_flags_cli`/`restore_flags` definitions may cause warnings or errors depending on how headers are included transitively.

3. **Possible failures:** The `perf.h` floating-point code may compile (GCC allows `double` in freestanding mode) but will produce incorrect codegen if SSE is not properly initialized.

### What Will Fail on First Boot

1. **Guaranteed failure (BLOCKER 6):** UEFI firmware will reject the ELF-format BOOTX64.EFI and refuse to load it.

2. **If bootloader format is fixed:** The kernel jump will triple-fault due to unmapped higher-half addresses (BLOCKER 7).

3. **If paging is fixed:** kprintf will print garbage or crash due to unsupported format specifiers (BLOCKER 2).

4. **If kprintf is fixed:** System will print "No initrd found" and idle (BLOCKER 8).

### Fallback Plan

If a full boot is not achievable immediately:

1. **Milestone 1 -- Bootloader only:** Fix BLOCKER 6, test with OVMF. Verify the bootloader banner appears on serial output. This proves UEFI handoff works.

2. **Milestone 2 -- Kernel banner:** Fix BLOCKERS 5, 6, 7. Get the kernel to print its version banner. This proves ELF loading and higher-half paging work.

3. **Milestone 3 -- Idle loop:** Fix BLOCKERS 2, 3, 4. Get the kernel to initialize all subsystems and reach the idle loop. This proves memory, interrupts, and scheduling initialize.

4. **Milestone 4 -- Init in usermode:** Fix BLOCKER 8, create initrd. Get the init process to print its banner in user mode. This proves syscalls and user mode transitions work.

5. **Milestone 5 -- Shell:** Get the shell to spawn and accept commands. This is a full boot.

---

## Troubleshooting Guide

### "UEFI Shell appears instead of bootloader"
The firmware cannot find BOOTX64.EFI. Verify the ISO/ESP has the file at `\EFI\BOOT\BOOTX64.EFI` and that it is a valid PE/COFF binary.

### "QEMU immediately reboots"
Triple fault. Most likely cause: jumping to an unmapped virtual address (BLOCKER 7). Run QEMU with `-d int,cpu_reset -D qemu.log` to see the exception.

### "Serial output shows garbage"
kprintf format string mismatch (BLOCKER 2). The va_list is getting out of sync because unsupported format specifiers skip the wrong number of bytes.

### "Compilation fails with 'stdio.h: No such file or directory'"
BLOCKER 5. The cross-compiler does not provide hosted headers. Replace with kernel-local equivalents.

### "BOOTX64.EFI: not recognized as a UEFI application"
BLOCKER 6. The file is in ELF format, not PE/COFF. Use objcopy or a UEFI SDK.

### "Page fault at 0xFFFFFFFF8xxxxxxx"
BLOCKER 7. The higher-half virtual address range is not mapped. The bootloader must set up page tables before jumping.

### "No initrd found"
BLOCKER 8. The bootloader did not load an initrd, or boot_info fields are zero.

### "GDT/IDT-related crash"
Check that GDT entries 3 and 4 are configured as user-mode code/data segments with RPL=3. Verify the TSS is properly installed.

### "Syscall from userspace causes crash"
ISSUE M3. The syscall entry does not switch stacks. The kernel is executing on the user stack, which may be unmapped or at an invalid address in kernel space.

---

## Honest Assessment

### Is this system REALLY ready to boot?

**No.** It is approximately 85% architecturally complete but 0% operationally bootable.

The system has:
- A well-designed architecture with all major subsystems
- Correct use of x86_64 features (long mode, SYSCALL/SYSRET, IRETQ)
- A solid build system with proper cross-compilation setup
- Extensive documentation (376 markdown files, more documentation than code)
- Good code quality practices (static analysis, CI/CD, testing infrastructure)

The system lacks:
- A bootloader that produces the correct binary format (PE/COFF vs ELF)
- Page tables for the kernel's higher-half virtual addresses
- An initrd and the mechanism to load it
- A kprintf that supports the format specifiers the kernel actually uses
- Clean compilation (18 files reference non-existent standard library headers)

### What needs the most work?

In priority order:
1. **Bootloader format** (BLOCKER 6) -- 2-4 hours to fix
2. **Higher-half paging** (BLOCKER 7) -- 4-8 hours to fix properly
3. **Initrd pipeline** (BLOCKER 8) -- 2-3 hours to create
4. **kprintf enhancement** (BLOCKER 2) -- 1-2 hours to fix
5. **Header cleanup** (BLOCKER 5) -- 1-2 hours of search-and-replace
6. **QEMU script** (BLOCKER 1) -- 15 minutes
7. **Float removal** (BLOCKER 3) -- 30 minutes
8. **Duplicate definitions** (BLOCKER 4) -- 15 minutes

**Total estimated effort to reach a bootable state:** 12-20 hours of focused, competent OS development work.

### The 63-agent problem

This project has been built by 63 separate AI agents, each adding components without compiling or testing. The result is a system where:
- Every piece exists in isolation
- No integration testing has occurred
- Interfaces between components have subtle mismatches
- Some agents wrote code assuming a hosted (Linux-like) environment rather than freestanding
- The PE loader subsystem (`kernel/pe/`) appears to be written for a Linux userspace test harness, not for the kernel

The path forward is to focus on the minimal boot path (bootloader -> kernel -> idle loop) and get that compiling and running first, then incrementally add subsystems.

---

## Files Referenced in This Report

Critical files to examine and fix:

| File | Issue |
|------|-------|
| `boot/Makefile` | BLOCKER 6: ELF output format |
| `boot/loader.c` | BLOCKER 7: No paging setup; BLOCKER 8: No initrd loading |
| `boot/boot.asm` | BLOCKER 6: `-f elf64` needs PE/COFF |
| `kernel/kernel.c` | BLOCKER 2: kprintf format strings |
| `kernel/lib/printf.c` | BLOCKER 2: Missing format specifiers |
| `kernel/include/perf.h` | BLOCKER 3: Floating-point in kernel |
| `kernel/include/spinlock.h` | BLOCKER 4: Duplicate definitions |
| `kernel/include/x86_64.h` | BLOCKER 4: Duplicate definitions |
| `kernel/pe/*.c` (7 files) | BLOCKER 5: `<stdio.h>` includes |
| `kernel/fs/autofs/*.c` (11 files) | BLOCKER 5: `<stdio.h>` includes |
| `kernel/linker.ld` | BLOCKER 7: Higher-half base address |
| `scripts/run-qemu.sh` | BLOCKER 1: Missing OVMF |
| `scripts/build-iso.py` | ISSUE M5: Wrong kernel path |
| `kernel/arch/x86_64/gdt.c` | ISSUE M2: User segment entries |
| `kernel/arch/x86_64/syscall.asm` | ISSUE M3: No kernel stack switch |
