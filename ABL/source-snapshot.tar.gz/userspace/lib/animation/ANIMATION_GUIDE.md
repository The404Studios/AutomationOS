# AutomationOS Animation System Guide

Complete guide to the AutomationOS animation engine, UI animations, and visual effects.

## Table of Contents

1. [Overview](#overview)
2. [Core Animation Engine](#core-animation-engine)
3. [Easing Functions](#easing-functions)
4. [Animation Types](#animation-types)
5. [UI Widget Animations](#ui-widget-animations)
6. [Window Manager Animations](#window-manager-animations)
7. [Performance Guidelines](#performance-guidelines)
8. [Best Practices](#best-practices)
9. [Examples](#examples)

---

## Overview

The AutomationOS animation system provides a powerful, GPU-accelerated framework for creating smooth, professional animations throughout the OS.

### Key Features

- **60 FPS rendering** with vsync support
- **30+ easing functions** (quadratic, cubic, elastic, bounce, spring physics, etc.)
- **Multiple animation types**: values, colors, transforms, rectangles, keyframes
- **Spring physics** for natural motion
- **Custom bezier curves** for precise control
- **Animation groups** for synchronized animations
- **Accessibility support** (reduce motion mode)
- **Auto-targeting** - animations automatically update target variables

### Architecture

```
┌─────────────────────────────────────────────┐
│              Animator                       │
│  (manages all active animations)            │
└─────────────────┬───────────────────────────┘
                  │
        ┌─────────┴──────────┐
        │                    │
┌───────▼────────┐  ┌────────▼─────────┐
│   Animations   │  │  Animation       │
│   (linked list)│  │  Groups          │
└───────┬────────┘  └──────────────────┘
        │
┌───────▼────────────────────────────────┐
│  Animation Types:                      │
│  • Value (float)                       │
│  • Color (RGBA)                        │
│  • Transform (2D transform matrix)     │
│  • Rectangle (x, y, w, h)             │
│  • Keyframe (multi-point)             │
│  • Spring (physics-based)             │
└────────────────────────────────────────┘
```

---

## Core Animation Engine

### Initialization

```c
#include "animator.h"

// Create animator
animator_t *animator = animator_create();

// Enable reduce motion (accessibility)
animator_set_reduce_motion(animator, false);

// Set global speed multiplier
animator_set_global_speed(animator, 1.0f);  // 1.0 = normal, 0.5 = half speed
```

### Update Loop

```c
// In your main render loop (60 FPS)
while (running) {
    // Update all animations
    animator_update(animator);
    
    // Render frame
    render_frame();
}
```

### Cleanup

```c
animator_destroy(animator);  // Frees all animations
```

---

## Easing Functions

### Available Easing Functions

**Linear:**
- `EASE_LINEAR` - No easing, constant speed

**Quadratic:**
- `EASE_IN_QUAD` - Accelerates slowly
- `EASE_OUT_QUAD` - Decelerates slowly  
- `EASE_IN_OUT_QUAD` - Accelerate then decelerate

**Cubic:**
- `EASE_IN_CUBIC` - Accelerates moderately
- `EASE_OUT_CUBIC` - Decelerates moderately (most common)
- `EASE_IN_OUT_CUBIC` - Smooth acceleration/deceleration

**Quartic:**
- `EASE_IN_QUART` - Strong acceleration
- `EASE_OUT_QUART` - Strong deceleration
- `EASE_IN_OUT_QUART` - Very smooth curve

**Quintic:**
- `EASE_IN_QUINT` - Very strong acceleration
- `EASE_OUT_QUINT` - Very strong deceleration
- `EASE_IN_OUT_QUINT` - Extremely smooth

**Sinusoidal:**
- `EASE_IN_SINE` - Gentle start
- `EASE_OUT_SINE` - Gentle end
- `EASE_IN_OUT_SINE` - Very natural motion

**Exponential:**
- `EASE_IN_EXPO` - Explosive start
- `EASE_OUT_EXPO` - Sudden stop
- `EASE_IN_OUT_EXPO` - Dramatic effect

**Circular:**
- `EASE_IN_CIRC` - Slight acceleration
- `EASE_OUT_CIRC` - Slight deceleration
- `EASE_IN_OUT_CIRC` - Smooth arc

**Back (Overshoot):**
- `EASE_IN_BACK` - Pulls back before starting
- `EASE_OUT_BACK` - Overshoots then settles (great for UI!)
- `EASE_IN_OUT_BACK` - Pulls back and overshoots

**Elastic:**
- `EASE_IN_ELASTIC` - Elastic snap at start
- `EASE_OUT_ELASTIC` - Bouncy overshoot (fun!)
- `EASE_IN_OUT_ELASTIC` - Elastic both sides

**Bounce:**
- `EASE_IN_BOUNCE` - Bounces at start
- `EASE_OUT_BOUNCE` - Bounces at end (playful!)
- `EASE_IN_OUT_BOUNCE` - Bounces both sides

**Special:**
- `EASE_SPRING` - Spring physics simulation
- `EASE_CUSTOM_BEZIER` - Custom cubic bezier curve

### Easing Recommendations

| Use Case | Recommended Easing |
|----------|-------------------|
| Button hover | `EASE_OUT_QUAD` |
| Button click | `EASE_OUT_CUBIC` |
| Menu open | `EASE_OUT_CUBIC` |
| Dialog appear | `EASE_OUT_CUBIC` |
| Window open | `EASE_OUT_BACK` |
| Smooth scrolling | `EASE_IN_OUT_CUBIC` |
| Attention grabber | `EASE_OUT_ELASTIC` |
| Playful interaction | `EASE_OUT_BOUNCE` |
| Natural motion | `EASE_SPRING` |

---

## Animation Types

### 1. Value Animation

Animate a single float value.

```c
// Basic value animation
animation_t *anim = anim_from_to(animator, 0.0f, 100.0f, DURATION_NORMAL, EASE_OUT_CUBIC);
anim_start(anim);

// Auto-update a variable
float my_value = 0.0f;
animation_t *anim = anim_from_to(animator, 0.0f, 1.0f, DURATION_NORMAL, EASE_OUT_QUAD);
anim_set_target(anim, &my_value);  // my_value will update automatically
anim_start(anim);

// Get current value manually
float current = anim_get_current_value(anim);
```

### 2. Color Animation

Animate RGBA colors with smooth interpolation.

```c
color_t from = { .r = 1.0f, .g = 0.0f, .b = 0.0f, .a = 1.0f };  // Red
color_t to = { .r = 0.0f, .g = 0.0f, .b = 1.0f, .a = 1.0f };    // Blue

animation_t *anim = anim_color(animator, from, to, DURATION_NORMAL, EASE_LINEAR);
anim_set_target_color(anim, &widget->bg_color);
anim_start(anim);
```

### 3. Transform Animation

Animate 2D transforms (translation, scale, rotation).

```c
transform_t from = {
    .tx = 0.0f, .ty = 0.0f,
    .sx = 1.0f, .sy = 1.0f,
    .rotation = 0.0f,
    .anchor_x = 0.5f, .anchor_y = 0.5f
};

transform_t to = {
    .tx = 100.0f, .ty = 50.0f,
    .sx = 1.5f, .sy = 1.5f,
    .rotation = M_PI / 4.0f,  // 45 degrees
    .anchor_x = 0.5f, .anchor_y = 0.5f
};

animation_t *anim = anim_transform(animator, from, to, DURATION_NORMAL, EASE_OUT_CUBIC);
anim_set_target_transform(anim, &window->transform);
anim_start(anim);
```

### 4. Rectangle Animation

Animate position and size simultaneously.

```c
rect_f_t from = { .x = 100.0f, .y = 100.0f, .w = 200.0f, .h = 150.0f };
rect_f_t to = { .x = 300.0f, .y = 200.0f, .w = 400.0f, .h = 300.0f };

animation_t *anim = anim_rect(animator, from, to, DURATION_NORMAL, EASE_IN_OUT_CUBIC);
anim_set_target_rect(anim, &window->geometry);
anim_start(anim);
```

### 5. Keyframe Animation

Multi-point animation with different easing between each keyframe.

```c
animation_t *anim = anim_keyframe(animator);

// Add keyframes (time, value, easing to next keyframe)
anim_add_keyframe(anim, 0.0f, 0.0f, EASE_LINEAR);
anim_add_keyframe(anim, 0.3f, 100.0f, EASE_OUT_CUBIC);
anim_add_keyframe(anim, 0.7f, 50.0f, EASE_IN_CUBIC);
anim_add_keyframe(anim, 1.0f, 100.0f, EASE_OUT_BOUNCE);

anim->duration = DURATION_SLOW;
anim_set_target(anim, &my_value);
anim_start(anim);
```

### 6. Spring Physics Animation

Physically-based spring animation for natural motion.

```c
spring_params_t spring = {
    .stiffness = 200.0f,    // Higher = faster oscillation
    .damping = 20.0f,       // Higher = less oscillation
    .mass = 1.0f,           // Mass of object
    .velocity = 0.0f        // Initial velocity
};

animation_t *anim = anim_spring(animator, 0.0f, 100.0f, &spring);
anim_set_target(anim, &my_value);
anim_start(anim);

// Or use presets
animation_t *anim = anim_spring(animator, 0.0f, 100.0f, &SPRING_BOUNCY);
```

### 7. Custom Bezier Curve

Define your own easing curve with cubic bezier.

```c
animation_t *anim = anim_from_to(animator, 0.0f, 100.0f, DURATION_NORMAL, EASE_CUSTOM_BEZIER);
anim_set_bezier(anim, 0.42f, 0.0f, 0.58f, 1.0f);  // Custom curve
anim_start(anim);
```

---

## Animation Control

### Start, Pause, Resume, Stop

```c
animation_t *anim = anim_from_to(animator, 0.0f, 100.0f, DURATION_NORMAL, EASE_OUT_CUBIC);

anim_start(anim);      // Start animation
anim_pause(anim);      // Pause
anim_resume(anim);     // Resume from pause
anim_stop(anim);       // Jump to end immediately
anim_cancel(anim);     // Cancel without completing
```

### Delay

```c
animation_t *anim = anim_from_to(animator, 0.0f, 1.0f, DURATION_NORMAL, EASE_OUT_QUAD);
anim_set_delay(anim, 500000);  // 500ms delay before starting
anim_start(anim);
```

### Repeat

```c
animation_t *anim = anim_from_to(animator, 0.0f, 1.0f, DURATION_NORMAL, EASE_LINEAR);

// Repeat 3 times
anim_set_repeat(anim, 3);

// Infinite loop
anim_set_repeat(anim, -1);

// With auto-reverse (ping-pong effect)
anim_set_auto_reverse(anim, true);

anim_start(anim);
```

### Callbacks

```c
void on_start(void *user_data) {
    printf("Animation started!\n");
}

void on_update(float value, void *user_data) {
    printf("Current value: %f\n", value);
}

void on_complete(void *user_data) {
    printf("Animation finished!\n");
}

animation_t *anim = anim_from_to(animator, 0.0f, 100.0f, DURATION_NORMAL, EASE_OUT_CUBIC);
anim_on_start(anim, on_start, NULL);
anim_on_update(anim, on_update, NULL);
anim_on_complete(anim, on_complete, NULL);
anim_start(anim);
```

### Query Animation State

```c
bool running = anim_is_running(anim);
bool finished = anim_is_finished(anim);
float progress = anim_get_progress(anim);  // 0.0 - 1.0
float value = anim_get_current_value(anim);
```

---

## Animation Groups

Synchronize multiple animations.

```c
// Create group
animation_group_t *group = anim_group_create();

// Add animations
animation_t *anim1 = anim_from_to(animator, 0.0f, 100.0f, DURATION_NORMAL, EASE_OUT_CUBIC);
animation_t *anim2 = anim_from_to(animator, 0.0f, 50.0f, DURATION_NORMAL, EASE_OUT_CUBIC);

anim_group_add(group, anim1);
anim_group_add(group, anim2);

// Start all simultaneously
anim_group_start(group);

// Cleanup
anim_group_destroy(group);
```

---

## UI Widget Animations

Pre-built animations for common UI elements.

### Button Animations

```c
#include "ui_animations.h"

widget_anim_state_t button_state = {
    .scale = 1.0f,
    .opacity = 1.0f,
    .offset_x = 0.0f,
    .offset_y = 0.0f,
    .bg_color = { .r = 0.2f, .g = 0.6f, .b = 1.0f, .a = 1.0f },
    .visible = true
};

// On hover
color_t hover_color = { .r = 0.3f, .g = 0.7f, .b = 1.0f, .a = 1.0f };
ui_button_hover(animator, &button_state, hover_color);

// On click
ui_button_click(animator, &button_state);

// Pulse animation (attention)
animation_t *pulse = ui_button_pulse(animator, &button_state);
// Stop pulsing
anim_cancel(pulse);
```

### Menu Animations

```c
widget_anim_state_t menu_state = { /* ... */ };

// Open menu
ui_menu_open(animator, &menu_state);

// Close menu
ui_menu_close(animator, &menu_state);

// Cascade menu items
widget_anim_state_t items[5];
ui_menu_cascade(animator, items, 5);  // 50ms stagger between items
```

### Dialog Animations

```c
widget_anim_state_t dialog_state = { /* ... */ };
widget_anim_state_t backdrop_state = { /* ... */ };

// Show dialog with backdrop dim
ui_dialog_show(animator, &dialog_state, &backdrop_state);

// Hide dialog
ui_dialog_hide(animator, &dialog_state, &backdrop_state);

// Shake on error
ui_dialog_shake(animator, &dialog_state);
```

### Progress Bar

```c
float progress_value = 0.0f;

// Animate to new value
ui_progress_animate(animator, &progress_value, 0.75f);

// Indeterminate animation
float shimmer_offset = 0.0f;
animation_t *anim = ui_progress_indeterminate(animator, &shimmer_offset);

// Complete flash
widget_anim_state_t bar_state = { /* ... */ };
ui_progress_complete(animator, &bar_state);
```

### Toast Notifications

```c
widget_anim_state_t toast_state = { /* ... */ };

// Slide in from right
ui_toast_slide_in(animator, &toast_state, true);

// Auto-dismiss after 3 seconds
ui_toast_auto_dismiss(animator, &toast_state, 3000);
```

---

## Window Manager Animations

### Window Lifecycle

```c
#include "window_animations.h"

window_anim_t window = {
    .geometry = { .x = 100, .y = 100, .w = 800, .h = 600 },
    .opacity = 0.0f,
    .scale = 1.0f,
    .visible = false
};

// Open window
wm_window_open(animator, &window);

// Close window
wm_window_close(animator, &window);

// Minimize to dock
wm_window_minimize(animator, &window, true);  // true = genie effect

// Maximize
rect_f_t fullscreen = { .x = 0, .y = 0, .w = 1920, .h = 1080 };
wm_window_maximize(animator, &window, fullscreen);
```

### Focus Transitions

```c
// Focus window (scale up + shadow)
wm_window_focus(animator, &window);

// Unfocus (dim + reduce shadow)
wm_window_unfocus(animator, &window);

// Urgent/attention animation
animation_t *attention = wm_window_attention(animator, &window);
```

### Workspace Switching

```c
window_anim_t workspace_windows[10];
uint32_t count = 10;

// Slide transition
wm_workspace_slide(animator, workspace_windows, count, true);  // true = slide left

// Fade transition
wm_workspace_fade(animator, old_windows, old_count, new_windows, new_count);

// 3D cube rotation
wm_workspace_cube(animator, workspace_windows, count, M_PI / 2.0f);
```

---

## Performance Guidelines

### Target Frame Budget

- **60 FPS** = 16.67ms per frame
- Animation update should take < 1ms
- Leave room for rendering (10-12ms)

### Optimization Tips

1. **Use GPU acceleration** for all visual effects
2. **Batch animations** - update all in single pass
3. **Avoid memory allocation** during animation
4. **Use dirty rectangles** - only redraw changed areas
5. **Enable vsync** to prevent tearing
6. **Reduce motion mode** - respect accessibility settings

### Reduce Motion Mode

```c
// Enable for users with motion sensitivity
animator_set_reduce_motion(animator, true);

// In reduce motion mode:
// - Animations are instant or very fast (50ms)
// - No elastic/bounce/spring effects
// - Crossfades instead of slides
// - Essential animations only
```

### Performance Monitoring

```c
// Get current FPS
uint32_t fps = animator->fps;

// Count active animations
uint32_t active = animator->animation_count;

// Warn if too many animations
if (active > 50) {
    fprintf(stderr, "Warning: %u active animations!\n", active);
}
```

---

## Best Practices

### Timing Guidelines

| Duration | Use Case |
|----------|----------|
| 50-100ms | Micro-interactions (hover, focus) |
| 150-200ms | UI transitions (menus, dialogs) |
| 250-350ms | Window operations (open, close, move) |
| 400-500ms | Workspace switches, complex transitions |
| 600ms+ | Attention animations, special effects |

### Consistency

- Use same durations for similar operations
- Stick to 2-3 easing curves throughout app
- Match animation style to brand personality

### User Control

- Provide "Reduce Motion" setting
- Allow disabling specific effect types
- Respect system animation preferences

### Don't Overdo It

- Not everything needs animation
- Subtle is often better
- Instant feedback is sometimes best
- Performance > flashiness

### Testing Checklist

- [ ] Test at 60 FPS, 30 FPS, and during lag
- [ ] Test with reduce motion enabled
- [ ] Test rapid user input (spam clicking)
- [ ] Test with 100+ concurrent animations
- [ ] Test on low-end hardware

---

## Examples

### Example 1: Button with All States

```c
typedef struct {
    widget_anim_state_t state;
    color_t normal_color;
    color_t hover_color;
    color_t active_color;
} animated_button_t;

void button_on_hover(animator_t *animator, animated_button_t *btn) {
    ui_button_hover(animator, &btn->state, btn->hover_color);
}

void button_on_leave(animator_t *animator, animated_button_t *btn) {
    ui_button_unhover(animator, &btn->state, btn->normal_color);
}

void button_on_click(animator_t *animator, animated_button_t *btn) {
    ui_button_click(animator, &btn->state);
}
```

### Example 2: Smooth Window Open

```c
void open_window_smooth(animator_t *animator, window_t *win) {
    window_anim_t anim = {
        .geometry = { .x = win->x, .y = win->y, .w = win->width, .h = win->height },
        .opacity = 0.0f,
        .scale = 0.9f,
        .shadow_opacity = 0.0f,
        .visible = true
    };
    
    wm_window_open(animator, &anim);
    
    // Copy animated values back to window
    win->opacity = anim.opacity;
    win->scale = anim.scale;
}
```

### Example 3: Loading Spinner

```c
float rotation = 0.0f;
animation_t *spinner = ui_loading_spinner(animator, &rotation);

// In render loop:
render_spinner(x, y, rotation);

// Stop spinner when done:
anim_cancel(spinner);
```

### Example 4: Chained Animations

```c
// Fade out, then fade in
animation_t *fade_out = anim_from_to(animator, 1.0f, 0.0f, DURATION_NORMAL, EASE_IN_QUAD);
anim_set_target(fade_out, &opacity);

animation_t *fade_in = anim_from_to(animator, 0.0f, 1.0f, DURATION_NORMAL, EASE_OUT_QUAD);
anim_set_target(fade_in, &opacity);

// Start fade_in when fade_out completes
void chain_callback(void *user_data) {
    animation_t *next = (animation_t*)user_data;
    anim_start(next);
}

anim_on_complete(fade_out, chain_callback, fade_in);
anim_start(fade_out);
```

### Example 5: Parallax Effect

```c
// Background moves slower than foreground
float bg_offset = 0.0f;
float fg_offset = 0.0f;

animation_t *bg_anim = anim_from_to(animator, 0.0f, 100.0f, DURATION_SLOW, EASE_LINEAR);
anim_set_target(bg_anim, &bg_offset);

animation_t *fg_anim = anim_from_to(animator, 0.0f, 200.0f, DURATION_SLOW, EASE_LINEAR);
anim_set_target(fg_anim, &fg_offset);

// Start together
animation_group_t *group = anim_group_create();
anim_group_add(group, bg_anim);
anim_group_add(group, fg_anim);
anim_group_start(group);
```

---

## Debugging

### Enable Animation Debugging

```c
// Print animation info
void debug_animation(animation_t *anim) {
    printf("Animation ID: %u\n", anim->id);
    printf("Type: %d\n", anim->type);
    printf("State: %d\n", anim->state);
    printf("Progress: %.2f%%\n", anim_get_progress(anim) * 100.0f);
    printf("Current value: %.2f\n", anim_get_current_value(anim));
}

// Count active animations
uint32_t count_animations(animator_t *animator) {
    uint32_t count = 0;
    animation_t *anim = animator->animations;
    while (anim) {
        if (anim->state == ANIM_STATE_RUNNING) count++;
        anim = anim->next;
    }
    return count;
}
```

---

## API Reference Summary

### Animator Functions
- `animator_create()` - Create animator
- `animator_destroy()` - Destroy animator
- `animator_update()` - Update all animations (call per frame)
- `animator_set_reduce_motion()` - Set accessibility mode
- `animator_set_global_speed()` - Adjust all animation speeds

### Animation Creation
- `anim_create()` - Basic animation
- `anim_from_to()` - Value animation with range
- `anim_spring()` - Spring physics animation
- `anim_color()` - Color animation
- `anim_transform()` - 2D transform animation
- `anim_rect()` - Rectangle animation
- `anim_keyframe()` - Multi-keyframe animation

### Animation Control
- `anim_start()` - Start animation
- `anim_pause()` - Pause
- `anim_resume()` - Resume
- `anim_stop()` - Jump to end
- `anim_cancel()` - Cancel animation
- `anim_seek()` - Jump to specific time

### Animation Configuration
- `anim_set_delay()` - Add start delay
- `anim_set_repeat()` - Set repeat count
- `anim_set_auto_reverse()` - Enable ping-pong
- `anim_set_target()` - Auto-update target variable
- `anim_set_bezier()` - Custom bezier curve

### Callbacks
- `anim_on_start()` - Called when starting
- `anim_on_update()` - Called each frame
- `anim_on_complete()` - Called when finished
- `anim_on_cancel()` - Called when canceled

### Animation Groups
- `anim_group_create()` - Create group
- `anim_group_add()` - Add animation to group
- `anim_group_start()` - Start all animations
- `anim_group_destroy()` - Destroy group

---

## Conclusion

The AutomationOS animation system provides everything needed to create smooth, professional animations throughout the OS. Follow the guidelines in this document to create delightful user experiences that feel responsive and polished.

For questions or issues, see `examples/animation_demo.c` or consult the source code in `userspace/lib/animation/`.

**Make it feel like magic!** ✨
