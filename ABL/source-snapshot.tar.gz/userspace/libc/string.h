// userspace/libc/string.h - String function declarations

#ifndef STRING_H
#define STRING_H

#ifndef NULL
#define NULL ((void*)0)
#endif

// String functions
unsigned long strlen(const char* str);
int strcmp(const char* s1, const char* s2);
int strncmp(const char* s1, const char* s2, unsigned long n);
char* strcpy(char* dest, const char* src);
char* strncpy(char* dest, const char* src, unsigned long n);
char* strcat(char* dest, const char* src);
char* strchr(const char* str, int ch);

// Memory functions
void* memset(void* dest, int val, unsigned long count);
void* memcpy(void* dest, const void* src, unsigned long count);
void* memmove(void* dest, const void* src, unsigned long count);
int memcmp(const void* s1, const void* s2, unsigned long count);

#endif
