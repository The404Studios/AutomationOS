# AutomationOS Accessibility Testing Checklist

Quick checklist for ensuring WCAG 2.1 Level AA compliance.

## Pre-Release Testing

### Visual Accessibility

- [ ] **Contrast Ratios**
  - [ ] All text has ≥4.5:1 contrast (normal text)
  - [ ] Large text (18pt+) has ≥3:1 contrast
  - [ ] UI elements have ≥3:1 contrast
  - [ ] Error states are clearly visible
  - [ ] Run automated contrast checker

- [ ] **Text Resize**
  - [ ] Test at 125% - content intact
  - [ ] Test at 150% - content intact
  - [ ] Test at 200% - content intact
  - [ ] No horizontal scrolling needed
  - [ ] No text truncation

- [ ] **Color Blind Support**
  - [ ] Test with Protanopia filter
  - [ ] Test with Deuteranopia filter
  - [ ] Test with Tritanopia filter
  - [ ] Test with Achromatopsia (grayscale)
  - [ ] Information not conveyed by color alone

- [ ] **High Contrast Mode**
  - [ ] All UI elements visible
  - [ ] Text readable
  - [ ] Icons distinguishable
  - [ ] Focus indicators visible

- [ ] **Screen Reader**
  - [ ] All buttons labeled
  - [ ] All links labeled
  - [ ] All images have alt text
  - [ ] Form fields labeled
  - [ ] Landmark regions defined
  - [ ] Live regions for dynamic content

- [ ] **Reduce Motion**
  - [ ] Animations can be disabled
  - [ ] No parallax effects when disabled
  - [ ] Essential motion only
  - [ ] Flash rate <3 per second

### Motor Accessibility

- [ ] **Keyboard Navigation**
  - [ ] Navigate entire UI with Tab/Shift+Tab
  - [ ] All buttons activatable with Enter/Space
  - [ ] Escape key closes modals
  - [ ] Arrow keys work in lists/menus
  - [ ] No keyboard traps detected
  - [ ] Logical tab order

- [ ] **Focus Indicators**
  - [ ] Focus visible on all elements
  - [ ] Focus indicator has ≥3:1 contrast
  - [ ] Focus indicator ≥2px width
  - [ ] Never hidden or obscured

- [ ] **Touch Targets**
  - [ ] All buttons ≥44×44px
  - [ ] All clickable icons ≥44×44px
  - [ ] List items ≥44px height
  - [ ] Adequate spacing between targets

- [ ] **Sticky Keys**
  - [ ] Activate with 5× Shift press
  - [ ] Works with Ctrl, Alt, Shift, Win
  - [ ] Audio feedback optional
  - [ ] Lock mode available

- [ ] **Mouse Keys**
  - [ ] Numpad controls mouse
  - [ ] Speed adjustable
  - [ ] Click, double-click, drag supported

- [ ] **Dwell Click**
  - [ ] Hover-to-click works
  - [ ] Dwell time configurable
  - [ ] Visual countdown shown

### Auditory Accessibility

- [ ] **Visual Alerts**
  - [ ] Screen flashes for sounds
  - [ ] Taskbar flash option
  - [ ] Flash rate safe (<3/sec)

- [ ] **Captions**
  - [ ] Captions for all audio
  - [ ] Synchronized with audio
  - [ ] Readable font and size
  - [ ] High contrast background

- [ ] **Mono Audio**
  - [ ] Stereo to mono conversion works
  - [ ] No audio loss

- [ ] **Audio Balance**
  - [ ] Left/right balance adjustable
  - [ ] Works in real-time

### Cognitive Accessibility

- [ ] **Simple Mode**
  - [ ] UI simplified
  - [ ] Larger buttons (≥48px)
  - [ ] Clear language
  - [ ] Consistent layout

- [ ] **Focus Assist**
  - [ ] Notifications blocked
  - [ ] Distractions minimized
  - [ ] Single-task focus

- [ ] **Extended Timeouts**
  - [ ] Timeouts can be extended
  - [ ] No data loss on timeout
  - [ ] Warning before timeout

- [ ] **Consistent Design**
  - [ ] Navigation always in same place
  - [ ] Actions always work the same
  - [ ] Predictable behavior

## Manual Test Scenarios

### Scenario 1: Keyboard-Only User

1. [ ] Boot system without mouse connected
2. [ ] Login using keyboard only
3. [ ] Navigate to Settings
4. [ ] Change at least 3 settings
5. [ ] Open and close windows
6. [ ] Switch between applications
7. [ ] Shut down system
8. [ ] **Result:** All tasks completable

### Scenario 2: Screen Reader User

1. [ ] Enable screen reader
2. [ ] Navigate UI using only audio cues
3. [ ] Verify all elements are announced
4. [ ] Test form completion
5. [ ] Test error messages
6. [ ] Test notifications
7. [ ] **Result:** All information accessible

### Scenario 3: Low Vision User

1. [ ] Enable high contrast mode
2. [ ] Set text size to 200%
3. [ ] Increase cursor size to extra large
4. [ ] Navigate entire UI
5. [ ] Read all text
6. [ ] Click all buttons
7. [ ] **Result:** All content readable and accessible

### Scenario 4: Color Blind User

1. [ ] Enable color blind filter (Deuteranopia)
2. [ ] Navigate UI
3. [ ] Identify all interactive elements
4. [ ] Verify no information lost
5. [ ] Test color-coded elements
6. [ ] **Result:** All information distinguishable

### Scenario 5: Motor Impairment User

1. [ ] Enable sticky keys
2. [ ] Enable dwell click
3. [ ] Navigate UI with limited dexterity simulation
4. [ ] Click buttons using dwell
5. [ ] Use modifier keys one at a time
6. [ ] **Result:** All tasks achievable

### Scenario 6: Deaf/Hard of Hearing User

1. [ ] Enable visual alerts
2. [ ] Enable captions
3. [ ] Trigger various system sounds
4. [ ] Verify visual feedback for all sounds
5. [ ] Check caption accuracy
6. [ ] **Result:** No audio-only information

## Automated Tests

### Run Validation Tool

```bash
./tools/accessibility_validator
```

Expected output:
```
Contrast Tests: 10/10 passed
Touch Target Tests: 6/6 passed
Color Blind Filter Tests: PASS
Keyboard Navigation Tests: PASS
Text Resize Tests: PASS
Screen Reader Tests: PASS
Reduced Motion Tests: PASS

WCAG 2.1 Level AA Compliance: ✓ COMPLIANT
```

### Check for Common Issues

- [ ] Run contrast checker on all screens
- [ ] Validate all touch targets ≥44px
- [ ] Check tab order on all forms
- [ ] Verify focus indicators everywhere
- [ ] Test with screen reader (NVDA/JAWS)
- [ ] Validate HTML/ARIA semantics

## WCAG 2.1 Level AA Criteria

### Perceivable (12 criteria)

- [ ] 1.1.1 - Non-text Content
- [ ] 1.2.2 - Captions (Prerecorded)
- [ ] 1.2.4 - Captions (Live)
- [ ] 1.2.5 - Audio Description
- [ ] 1.3.1 - Info and Relationships
- [ ] 1.3.2 - Meaningful Sequence
- [ ] 1.3.3 - Sensory Characteristics
- [ ] 1.4.1 - Use of Color
- [ ] 1.4.2 - Audio Control
- [ ] 1.4.3 - Contrast (Minimum)
- [ ] 1.4.4 - Resize Text
- [ ] 1.4.5 - Images of Text

### Operable (13 criteria)

- [ ] 2.1.1 - Keyboard
- [ ] 2.1.2 - No Keyboard Trap
- [ ] 2.2.1 - Timing Adjustable
- [ ] 2.2.2 - Pause, Stop, Hide
- [ ] 2.3.1 - Three Flashes or Below
- [ ] 2.4.1 - Bypass Blocks
- [ ] 2.4.2 - Page Titled
- [ ] 2.4.3 - Focus Order
- [ ] 2.4.4 - Link Purpose
- [ ] 2.4.5 - Multiple Ways
- [ ] 2.4.6 - Headings and Labels
- [ ] 2.4.7 - Focus Visible
- [ ] 2.5.5 - Target Size

### Understandable (9 criteria)

- [ ] 3.1.1 - Language of Page
- [ ] 3.2.1 - On Focus
- [ ] 3.2.2 - On Input
- [ ] 3.2.3 - Consistent Navigation
- [ ] 3.2.4 - Consistent Identification
- [ ] 3.3.1 - Error Identification
- [ ] 3.3.2 - Labels or Instructions
- [ ] 3.3.3 - Error Suggestion
- [ ] 3.3.4 - Error Prevention

### Robust (2 criteria)

- [ ] 4.1.1 - Parsing
- [ ] 4.1.2 - Name, Role, Value

**Total: 36 criteria**

## Sign-Off

### Developer

- [ ] All features implemented
- [ ] Automated tests pass
- [ ] Code reviewed
- [ ] Documentation updated

**Name:** ________________  
**Date:** ________________  
**Signature:** ________________

### QA Tester

- [ ] All manual tests completed
- [ ] No blocking issues
- [ ] Edge cases tested
- [ ] Regression tests pass

**Name:** ________________  
**Date:** ________________  
**Signature:** ________________

### Accessibility Specialist

- [ ] WCAG 2.1 AA compliant
- [ ] Screen reader compatible
- [ ] Keyboard accessible
- [ ] Ready for release

**Name:** ________________  
**Date:** ________________  
**Signature:** ________________

---

## Quick Reference

### Testing Tools

- **Contrast Checker:** `accessibility_validator`
- **Screen Readers:** NVDA (free), JAWS (commercial)
- **Color Blind Simulator:** Coblis (online)
- **Keyboard Tester:** Manual testing

### Standards

- **WCAG 2.1:** https://www.w3.org/WAI/WCAG21/quickref/
- **Section 508:** https://www.section508.gov/
- **EN 301 549:** European standard
- **ADA:** Americans with Disabilities Act

### Resources

- **AutomationOS Docs:** `docs/ACCESSIBILITY.md`
- **Validation Report:** `ACCESSIBILITY_VALIDATION_REPORT.md`
- **API Docs:** `userspace/lib/accessibility/README.md`

---

**Last Updated:** 2026-05-26  
**Version:** 1.0
