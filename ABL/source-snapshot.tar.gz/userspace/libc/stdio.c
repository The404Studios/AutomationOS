// userspace/libc/stdio.c - Standard I/O functions

#include "stdio.h"
#include "syscall.h"
#include "string.h"
#include "stdlib.h"

// Standard streams
static FILE stdin_file = { STDIN_FILENO, _FILE_READ, 0, 0, NULL, 0, 0, 0, _IONBF };
static FILE stdout_file = { STDOUT_FILENO, _FILE_WRITE, 0, 0, NULL, 0, 0, 0, _IOLBF };
static FILE stderr_file = { STDERR_FILENO, _FILE_WRITE, 0, 0, NULL, 0, 0, 0, _IONBF };

FILE* stdin = &stdin_file;
FILE* stdout = &stdout_file;
FILE* stderr = &stderr_file;

// Internal helper to print string
static void print_string(const char* str) {
    write(STDOUT_FILENO, str, strlen(str));
}

// Internal helper to print number in given base
static void print_number(long num, int base, int is_signed) {
    char buf[32];
    int i = 0;
    int is_negative = 0;

    if (is_signed && num < 0) {
        is_negative = 1;
        num = -num;
    }

    if (num == 0) {
        buf[i++] = '0';
    } else {
        while (num > 0) {
            int digit = num % base;
            buf[i++] = (digit < 10) ? ('0' + digit) : ('a' + digit - 10);
            num /= base;
        }
    }

    if (is_negative) {
        buf[i++] = '-';
    }

    // Print in reverse
    while (i > 0) {
        write(STDOUT_FILENO, &buf[--i], 1);
    }
}

typedef struct {
    char* buffer;
    size_t size;
    size_t count;
} format_buffer_t;

static void buffer_putc(format_buffer_t* out, char c) {
    if (out->buffer && out->size > 0 && out->count < out->size - 1) {
        out->buffer[out->count] = c;
    }
    out->count++;
}

static void buffer_puts(format_buffer_t* out, const char* str) {
    if (!str) {
        str = "(null)";
    }

    while (*str) {
        buffer_putc(out, *str++);
    }
}

static void buffer_put_number(format_buffer_t* out, unsigned long long value,
                              int base, int is_signed, int negative) {
    char tmp[32];
    int i = 0;

    if (negative && is_signed) {
        buffer_putc(out, '-');
    }

    if (value == 0) {
        buffer_putc(out, '0');
        return;
    }

    while (value > 0 && i < (int)sizeof(tmp)) {
        unsigned int digit = value % (unsigned int)base;
        tmp[i++] = (digit < 10) ? (char)('0' + digit) : (char)('a' + digit - 10);
        value /= (unsigned int)base;
    }

    while (i > 0) {
        buffer_putc(out, tmp[--i]);
    }
}

int vsnprintf(char* buffer, size_t size, const char* format, __builtin_va_list args) {
    format_buffer_t out = { buffer, size, 0 };

    for (const char* p = format; *p; p++) {
        if (*p != '%' || !*(p + 1)) {
            buffer_putc(&out, *p);
            continue;
        }

        p++;
        while (*p >= '0' && *p <= '9') {
            p++;
        }
        if (*p == '.') {
            p++;
            while (*p >= '0' && *p <= '9') {
                p++;
            }
        }

        int long_count = 0;
        while (*p == 'l') {
            long_count++;
            p++;
        }

        // If the string ended mid-specifier (e.g. "...%10" or "...%l"), stop
        // here instead of falling into the switch default, which would emit a
        // spurious '%' + NUL and read one past the terminator.
        if (*p == '\0') {
            break;
        }

        switch (*p) {
            case 's':
                buffer_puts(&out, __builtin_va_arg(args, const char*));
                break;
            case 'd':
            case 'i': {
                long long value = (long_count >= 2) ? __builtin_va_arg(args, long long) :
                                  (long_count == 1) ? __builtin_va_arg(args, long) :
                                                      __builtin_va_arg(args, int);
                unsigned long long magnitude = (value < 0) ? (unsigned long long)(-value) : (unsigned long long)value;
                buffer_put_number(&out, magnitude, 10, 1, value < 0);
                break;
            }
            case 'u':
            case 'x':
            case 'X': {
                unsigned long long value = (long_count >= 2) ? __builtin_va_arg(args, unsigned long long) :
                                           (long_count == 1) ? __builtin_va_arg(args, unsigned long) :
                                                               __builtin_va_arg(args, unsigned int);
                buffer_put_number(&out, value, (*p == 'u') ? 10 : 16, 0, 0);
                break;
            }
            case 'p':
                buffer_puts(&out, "0x");
                buffer_put_number(&out, (unsigned long long)__builtin_va_arg(args, void*), 16, 0, 0);
                break;
            case 'c':
                buffer_putc(&out, (char)__builtin_va_arg(args, int));
                break;
            case '%':
                buffer_putc(&out, '%');
                break;
            default:
                buffer_putc(&out, '%');
                buffer_putc(&out, *p);
                break;
        }
    }

    if (buffer && size > 0) {
        size_t idx = (out.count < size) ? out.count : size - 1;
        buffer[idx] = '\0';
    }

    return (int)out.count;
}

int snprintf(char* buffer, size_t size, const char* format, ...) {
    __builtin_va_list args;
    __builtin_va_start(args, format);
    int result = vsnprintf(buffer, size, format, args);
    __builtin_va_end(args);
    return result;
}

int fprintf(FILE* stream, const char* format, ...) {
    char buffer[512];
    int fd = stream ? stream->fd : STDOUT_FILENO;

    __builtin_va_list args;
    __builtin_va_start(args, format);
    int result = vsnprintf(buffer, sizeof(buffer), format, args);
    __builtin_va_end(args);

    size_t len = (result < (int)sizeof(buffer)) ? (size_t)result : sizeof(buffer) - 1;
    write(fd, buffer, len);
    return result;
}

// Printf with basic format specifiers
int printf(const char* format, ...) {
    __builtin_va_list args;
    __builtin_va_start(args, format);

    int count = 0;

    for (const char* p = format; *p; p++) {
        if (*p == '%' && *(p + 1)) {
            p++;
            switch (*p) {
                case 's': {
                    const char* str = __builtin_va_arg(args, const char*);
                    print_string(str ? str : "(null)");
                    count += strlen(str ? str : "(null)");
                    break;
                }
                case 'd': {
                    int val = __builtin_va_arg(args, int);
                    print_number(val, 10, 1);
                    count += 10; // Approximate
                    break;
                }
                case 'u': {
                    unsigned int val = __builtin_va_arg(args, unsigned int);
                    print_number(val, 10, 0);
                    count += 10;
                    break;
                }
                case 'x':
                case 'X': {
                    unsigned int val = __builtin_va_arg(args, unsigned int);
                    print_number(val, 16, 0);
                    count += 8;
                    break;
                }
                case 'p': {
                    void* ptr = __builtin_va_arg(args, void*);
                    write(STDOUT_FILENO, "0x", 2);
                    print_number((long)ptr, 16, 0);
                    count += 18;
                    break;
                }
                case 'c': {
                    char c = (char)__builtin_va_arg(args, int);
                    write(STDOUT_FILENO, &c, 1);
                    count++;
                    break;
                }
                case '%': {
                    write(STDOUT_FILENO, "%", 1);
                    count++;
                    break;
                }
                default: {
                    write(STDOUT_FILENO, "%", 1);
                    write(STDOUT_FILENO, p, 1);
                    count += 2;
                    break;
                }
            }
        } else {
            write(STDOUT_FILENO, p, 1);
            count++;
        }
    }

    __builtin_va_end(args);
    return count;
}

// Print string with newline
int puts(const char* str) {
    int len = strlen(str);
    write(STDOUT_FILENO, str, len);
    write(STDOUT_FILENO, "\n", 1);
    return len + 1;
}

// Print single character
int putchar(int c) {
    char ch = (char)c;
    write(STDOUT_FILENO, &ch, 1);
    return c;
}

// Get single character (stub)
int getchar(void) {
    char c;
    while (1) {
        long result = read(STDIN_FILENO, &c, 1);
        if (result > 0) {
            return (unsigned char)c;
        }
        if (result < 0) {
            return -1;
        }
        yield();
    }
}

// ============================================================================
// FILE OPERATIONS
// ============================================================================

// Parse mode string for fopen
static int parse_mode(const char* mode, int* flags, int* append_mode) {
    if (!mode || !mode[0]) {
        return -1;
    }

    *append_mode = 0;

    switch (mode[0]) {
        case 'r':
            *flags = O_RDONLY;
            if (mode[1] == '+') {
                *flags = O_RDWR;
            }
            break;
        case 'w':
            *flags = O_WRONLY | O_CREAT | O_TRUNC;
            if (mode[1] == '+') {
                *flags = O_RDWR | O_CREAT | O_TRUNC;
            }
            break;
        case 'a':
            *flags = O_WRONLY | O_CREAT | O_APPEND;
            *append_mode = 1;
            if (mode[1] == '+') {
                *flags = O_RDWR | O_CREAT | O_APPEND;
            }
            break;
        default:
            return -1;
    }

    return 0;
}

// Open file
FILE* fopen(const char* filename, const char* mode) {
    if (!filename || !mode) {
        return NULL;
    }

    int flags;
    int append_mode;
    if (parse_mode(mode, &flags, &append_mode) < 0) {
        return NULL;
    }

    int fd = open(filename, flags, 0644);
    if (fd < 0) {
        return NULL;
    }

    FILE* stream = (FILE*)malloc(sizeof(FILE));
    if (!stream) {
        close(fd);
        return NULL;
    }

    stream->fd = fd;
    stream->flags = 0;
    stream->error = 0;
    stream->eof = 0;
    stream->buffer = NULL;
    stream->buf_size = 0;
    stream->buf_pos = 0;
    stream->buf_count = 0;
    stream->buf_mode = _IONBF;

    if (flags & O_RDONLY || flags & O_RDWR) {
        stream->flags |= _FILE_READ;
    }
    if (flags & O_WRONLY || flags & O_RDWR) {
        stream->flags |= _FILE_WRITE;
    }

    // If in append mode, seek to end
    if (append_mode) {
        lseek(fd, 0, SEEK_END);
    }

    return stream;
}

// Close file
int fclose(FILE* stream) {
    if (!stream) {
        return EOF;
    }

    // Don't close standard streams
    if (stream == stdin || stream == stdout || stream == stderr) {
        return 0;
    }

    fflush(stream);

    int result = close(stream->fd);

    if (stream->buffer) {
        free(stream->buffer);
    }

    free(stream);

    return (result < 0) ? EOF : 0;
}

// Read from file
size_t fread(void* ptr, size_t size, size_t nmemb, FILE* stream) {
    if (!ptr || !stream || size == 0 || nmemb == 0) {
        return 0;
    }

    if (!(stream->flags & _FILE_READ)) {
        stream->error = 1;
        return 0;
    }

    size_t total_bytes = size * nmemb;
    size_t bytes_read = 0;
    char* dest = (char*)ptr;

    while (bytes_read < total_bytes) {
        ssize_t result = read(stream->fd, dest + bytes_read, total_bytes - bytes_read);

        if (result < 0) {
            stream->error = 1;
            break;
        }

        if (result == 0) {
            stream->eof = 1;
            stream->flags |= _FILE_EOF;
            break;
        }

        bytes_read += result;
    }

    return bytes_read / size;
}

// Write to file
size_t fwrite(const void* ptr, size_t size, size_t nmemb, FILE* stream) {
    if (!ptr || !stream || size == 0 || nmemb == 0) {
        return 0;
    }

    if (!(stream->flags & _FILE_WRITE)) {
        stream->error = 1;
        return 0;
    }

    size_t total_bytes = size * nmemb;
    size_t bytes_written = 0;
    const char* src = (const char*)ptr;

    while (bytes_written < total_bytes) {
        ssize_t result = write(stream->fd, src + bytes_written, total_bytes - bytes_written);

        if (result < 0) {
            stream->error = 1;
            break;
        }

        bytes_written += result;
    }

    return bytes_written / size;
}

// Seek in file
int fseek(FILE* stream, long offset, int whence) {
    if (!stream) {
        return -1;
    }

    stream->eof = 0;
    stream->flags &= ~_FILE_EOF;

    off_t result = lseek(stream->fd, offset, whence);
    return (result < 0) ? -1 : 0;
}

// Get current file position
long ftell(FILE* stream) {
    if (!stream) {
        return -1L;
    }

    off_t pos = lseek(stream->fd, 0, SEEK_CUR);
    return (long)pos;
}

// Rewind to beginning of file
void rewind(FILE* stream) {
    if (stream) {
        fseek(stream, 0L, SEEK_SET);
        stream->error = 0;
        stream->eof = 0;
        stream->flags &= ~(_FILE_ERROR | _FILE_EOF);
    }
}

// Get file position
int fgetpos(FILE* stream, fpos_t* pos) {
    if (!stream || !pos) {
        return -1;
    }

    long p = ftell(stream);
    if (p < 0) {
        return -1;
    }

    *pos = p;
    return 0;
}

// Set file position
int fsetpos(FILE* stream, const fpos_t* pos) {
    if (!stream || !pos) {
        return -1;
    }

    return fseek(stream, *pos, SEEK_SET);
}

// ============================================================================
// CHARACTER I/O
// ============================================================================

// Read character from file
int fgetc(FILE* stream) {
    unsigned char c;
    if (fread(&c, 1, 1, stream) != 1) {
        return EOF;
    }
    return c;
}

// Write character to file
int fputc(int c, FILE* stream) {
    unsigned char ch = (unsigned char)c;
    if (fwrite(&ch, 1, 1, stream) != 1) {
        return EOF;
    }
    return ch;
}

// Read line from file
char* fgets(char* s, int size, FILE* stream) {
    if (!s || size <= 0 || !stream) {
        return NULL;
    }

    int i = 0;
    while (i < size - 1) {
        int c = fgetc(stream);
        if (c == EOF) {
            if (i == 0) {
                return NULL;
            }
            break;
        }

        s[i++] = (char)c;

        if (c == '\n') {
            break;
        }
    }

    s[i] = '\0';
    return s;
}

// Write string to file
int fputs(const char* s, FILE* stream) {
    if (!s || !stream) {
        return EOF;
    }

    size_t len = strlen(s);
    if (fwrite(s, 1, len, stream) != len) {
        return EOF;
    }

    return 0;
}

// Unget character (simplified - no buffer)
int ungetc(int c, FILE* stream) {
    if (!stream || c == EOF) {
        return EOF;
    }

    // Simplified: just seek back one byte
    if (lseek(stream->fd, -1, SEEK_CUR) < 0) {
        return EOF;
    }

    return c;
}

// ============================================================================
// FORMATTED INPUT
// ============================================================================

// Simple scanf implementation (basic support)
int fscanf(FILE* stream, const char* format, ...) {
    if (!stream || !format) {
        return EOF;
    }

    // For now, just a stub that returns EOF
    // Full implementation would require parsing the format string
    // and reading from the stream accordingly
    (void)format;
    return EOF;
}

int scanf(const char* format, ...) {
    return fscanf(stdin, format);
}

int sscanf(const char* str, const char* format, ...) {
    // Stub implementation
    (void)str;
    (void)format;
    return EOF;
}

// ============================================================================
// ERROR HANDLING
// ============================================================================

// Clear error indicators
void clearerr(FILE* stream) {
    if (stream) {
        stream->error = 0;
        stream->eof = 0;
        stream->flags &= ~(_FILE_ERROR | _FILE_EOF);
    }
}

// Test end-of-file indicator
int feof(FILE* stream) {
    return stream ? stream->eof : 0;
}

// Test error indicator
int ferror(FILE* stream) {
    return stream ? stream->error : 0;
}

// Print error message
void perror(const char* s) {
    if (s && *s) {
        fprintf(stderr, "%s: ", s);
    }
    fprintf(stderr, "Error occurred\n");
}

// ============================================================================
// BUFFERING
// ============================================================================

// Set buffer
int setvbuf(FILE* stream, char* buf, int mode, size_t size) {
    if (!stream) {
        return -1;
    }

    if (mode != _IOFBF && mode != _IOLBF && mode != _IONBF) {
        return -1;
    }

    // Free existing buffer if we allocated it
    if (stream->buffer && stream->buf_size > 0) {
        free(stream->buffer);
        stream->buffer = NULL;
        stream->buf_size = 0;
    }

    stream->buf_mode = mode;

    if (mode == _IONBF) {
        return 0;
    }

    if (buf) {
        stream->buffer = buf;
        stream->buf_size = size;
    } else if (size > 0) {
        stream->buffer = (char*)malloc(size);
        if (!stream->buffer) {
            return -1;
        }
        stream->buf_size = size;
    }

    stream->buf_pos = 0;
    stream->buf_count = 0;

    return 0;
}

// Set buffer (simple version)
void setbuf(FILE* stream, char* buf) {
    if (buf) {
        setvbuf(stream, buf, _IOFBF, BUFSIZ);
    } else {
        setvbuf(stream, NULL, _IONBF, 0);
    }
}

// Flush buffer
int fflush(FILE* stream) {
    if (!stream) {
        // Flush all streams
        fflush(stdout);
        fflush(stderr);
        return 0;
    }

    if (stream->buffer && stream->buf_count > 0 && (stream->flags & _FILE_WRITE)) {
        ssize_t written = write(stream->fd, stream->buffer, stream->buf_count);
        if (written < 0) {
            stream->error = 1;
            return EOF;
        }
        stream->buf_count = 0;
        stream->buf_pos = 0;
    }

    return 0;
}
